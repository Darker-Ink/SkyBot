### Blue Sky!
An Multi Use Discord Bot! It's Got Stuff Like:
* Command Cooldowns
* Command Permissions
* OwnerOnly Commands

How to host this bot.

1. Get Node.js from https://nodejs.org.
2. Clone this repo by:
- Downloading the zip.
- Using git and doing `git clone https://github.com/DarkSky-Inc/Sky-Bot.git`
3. Run `npm i` in the bot directory.
4. Configure [config.json](https://github.com/DarkSky-Inc/Sky-Bot/blob/Master/config/config.json)
5. Run the bot by using `node index`, `node index.js` or `node .`!

### We Suggest using PM2
