const config = require('../config/config.json')
const exec = require('child_process').exec;
const date = require('date-and-time');
const now = new Date();
const time = (date.format(now, 'YYYY/MM/DD hh:mm'))
module.exports = {
    type: 'ready',
    async run(client) {
        console.log(`ready.js has been loaded`);

        let statuses = [
            `How are you today?`,
            `Serving ${client.guilds.cache.size} Servers`,
            `${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0).toLocaleString()} Users`,
            `He wasn\'t seen again`,
	        `Discord\'s API`,
            `The Time Is ${time}`,
	]

    let atcs = [
        `WATCHING`,
        `PLAYING`,
        `LISTENING`,
]
        setInterval(() => {
            let status = statuses[Math.floor(Math.random() * statuses.length)]
            let atttscs = atcs[Math.floor(Math.random() * atcs.length)]
            client.user.setActivity(status, {
                type: `${atttscs}`,
            });
        }, 60000)
    }
}
