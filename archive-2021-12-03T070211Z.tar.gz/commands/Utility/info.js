const Discord = require('discord.js');
module.exports = {
    name: 'info',
    ownerOnly: false,
    usage: "Info",
    description: 'Get Info',
    category: "Utility",
    cooldown: 8,
    run: async (client, message, args) => {
    }
}